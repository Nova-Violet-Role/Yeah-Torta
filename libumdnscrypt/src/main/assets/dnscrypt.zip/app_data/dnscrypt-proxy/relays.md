# Anonymized DNS relays

Anonymized DNS is a lightweight alternative to Tor and SOCKS proxies,
dedicated to DNS traffic. They hide the client IP address to DNS resolvers,
providing anonymity in addition to confidentiality and integrity.

DNS Anonymization is only compatible with servers supporting the
DNSCrypt protocol.

See the link below for more information:

https://github.com/DNSCrypt/dnscrypt-proxy/wiki/Anonymized-DNS


## anon-cs-austria

Wien, Austria Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRE5NC4xOTguNDEuMjM1OjQ0Mw


## anon-cs-austria6

Wien, Austria IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6Mjk6YTE6OjUzXTo0NDM


## anon-cs-barcelona

Barcelona, Spain Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIzNy4xMjAuMTQyLjExNTo0NDM


## anon-cs-barcelona6

Barcelona, Spain IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6MzU6MTc6OjUzXTo0NDM


## anon-cs-belgium

Brussels, Belgium Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gREzNy4xMjAuMjM2LjExOjQ0Mw


## anon-cs-belgium6

Brussels, Belgium IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMjAwMTphYzg6Mjc6MTAzOjo1M106NDQz


## anon-cs-berlin

Berlin, Germany Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gREzNy4xMjAuMjE3Ljc1OjQ0Mw


## anon-cs-berlin6

Berlin, Germany IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6MzY6NjE6OjUzXTo0NDM


## anon-cs-brazil

Brazil Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIxNzcuNTQuMTQ1LjEzMTo0NDM


## anon-cs-brazil6

Brazil IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRdbMjgwNDozOTFjOjA6Nzo6NTNdOjQ0Mw


## anon-cs-ch

Switzerland Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMxOTAuMjExLjI1NS4yMjc6NDQz


## anon-cs-ch6

Switzerland IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gR1bMmEwMjoyOWI4OmRjMDE6MjIyMDo6NTNdOjQ0Mw


## anon-cs-czech

Prague, Czech Republic Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMyMTcuMTM4LjIyMC4yNDM6NDQz


## anon-cs-czech6

Prague, Czech Republic IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6MzM6Nzc6OjUzXTo0NDM


## anon-cs-dc

US - Washington, DC Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRAxOTguNy41OC4yMjc6NDQz


## anon-cs-dc6

US - Washington, DC IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gR9bMjYwNDo5YTAwOjIwMTA6YTBiYjo2Ojo1M106NDQz


## anon-cs-de

Frankfurt, Germany Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gQ8xNDYuNzAuODIuMzo0NDM


## anon-cs-de6

Frankfurt, Germany IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMmEwZDo1NjAwOjFkOjk6OjUzXTo0NDM


## anon-cs-dus

Dusseldorf, Germany Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRI4OS4xNjMuMjIxLjE4MTo0NDM


## anon-cs-dus6

Dusseldorf, Germany IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRtbMjAwMTo0YmEwOmZmZWQ6NzY6OjUzXTo0NDM


## anon-cs-finland

Finland Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRE4My4xNDMuMjQyLjQzOjQ0Mw


## anon-cs-finland6

Finland IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRpbMmEwZDo1NjAwOjE0MjoxMTo6NTNdOjQ0Mw


## anon-cs-fl

US - Miami, FL Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIxNDYuNzAuMjQwLjIwMzo0NDM


## anon-cs-fl6

US - Miami, FL IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMmEwZDo1NjAwOjY6MTIzOjo1M106NDQz


## anon-cs-fr

France Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExNjMuMTcyLjM0LjU2OjQ0Mw


## anon-cs-fr6

France IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRxbMjAwMTpiYzg6MzJkNzoyMDBjOjo1M106NDQz


## anon-cs-ga

US - Atlanta, GA Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMxMzAuMTk1LjIxMi4yMTE6NDQz


## anon-cs-ga6

US - Atlanta, GA IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMmEwZDo1NjAwOjE0NTo1Ojo1M106NDQz


## anon-cs-hungary

Budapest, Hungary Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRE4Ni4xMDYuNzQuMjE5OjQ0Mw


## anon-cs-hungary6

Budapest, Hungary IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6MjY6NjE6OjUzXTo0NDM


## anon-cs-il

US - Chicago, IL Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMxOTUuMjQyLjIxMi4xMzE6NDQz


## anon-cs-il6

US - Chicago, IL IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMmEwZDo1NjAwOjE0NDoxOjo1M106NDQz


## anon-cs-india

India Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMxNjUuMjMxLjI1My4xNjM6NDQz


## anon-cs-la

US - Los Angeles, CA Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMxOTUuMjA2LjEwNC4yMDM6NDQz


## anon-cs-la6

US - Los Angeles, CA IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMmEwZDo1NjAwOjRmOjU6OjUzXTo0NDM


## anon-cs-london

London, England Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRE3OC4xMjkuMjQ4LjY3OjQ0Mw


## anon-cs-london6

London, England IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRtbMjAwMToxYjQwOjUwMDA6YTI6OjUzXTo0NDM


## anon-cs-manchester

Manchester, England Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExOTUuMTIuNDguMTcxOjQ0Mw


## anon-cs-manchester6

Manchester, England IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6OGI6NjE6OjUzXTo0NDM


## anon-cs-md

Moldova Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExNzYuMTIzLjQuMjMxOjQ0Mw


## anon-cs-md6

Moldova IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRtbMjAwMTo2Nzg6NmQ0OjUwMjM6OjUzXTo0NDM


## anon-cs-milan

Milan, Italy Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMyMTcuMTM4LjIxOS4yMTk6NDQz


## anon-cs-milan6

Milan, Italy IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6MjQ6YTE6OjUzXTo0NDM


## anon-cs-montreal

Montreal, Canada Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExNzYuMTEzLjc0LjE5OjQ0Mw


## anon-cs-montreal6

Montreal, Canada IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMmEwZDo1NjAwOjE5OjU6OjUzXTo0NDM


## anon-cs-nl

Netherlands Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExODUuMTA3LjgwLjg0OjQ0Mw


## anon-cs-nl6

Netherlands IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRpbMmEwMDoxNzY4OjYwMDE6ODo6NTNdOjQ0Mw


## anon-cs-norway

Oslo, Norway Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRI5MS4yMTkuMjE1LjIyNzo0NDM


## anon-cs-norway6

Oslo, Norway IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6Mzg6OTQ6OjUzXTo0NDM


## anon-cs-nv

US - Las Vegas, NV Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRA3OS4xMTAuNTMuNTE6NDQz


## anon-cs-nv6

US - Las Vegas, NV IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMmEwZDo1NjAwOjM6MTk6OjUzXTo0NDM


## anon-cs-nyc

US - New York City, NY Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExNDYuNzAuMTU0LjY3OjQ0Mw


## anon-cs-nyc6

US - New York City, NY IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMmEwZDo1NjAwOjI0OjU0Ojo1M106NDQz


## anon-cs-ore

US - Oregon Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExNzkuNjEuMjIzLjQ3OjQ0Mw


## anon-cs-ore6

US - Oregon IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRdbMjYwNTo2YzgwOjU6ZDo6NTNdOjQ0Mw


## anon-cs-poland

Warsaw, Poland Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gREzNy4xMjAuMjExLjkxOjQ0Mw


## anon-cs-poland6

Warsaw, Poland IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMmEwZDo1NjAwOjEzOjcxOjo1M106NDQz


## anon-cs-pt

Portugal Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRI5MS4yMDUuMjMwLjIyNDo0NDM


## anon-cs-pt6

Portugal IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRdbMmEwNjozMDQwOjplYzQ6NTNdOjQ0Mw


## anon-cs-ro

Romania Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRExNDYuNzAuNjYuMjI3OjQ0Mw


## anon-cs-sea

US - Seattle, WA Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRA2NC4xMjAuNS4yNTE6NDQz


## anon-cs-sea6

US - Seattle, WA IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRxbMjYwNzpmNWIyOjE6YTAwYjpiOjo1M106NDQz


## anon-cs-serbia

Belgrade, Serbia Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIzNy4xMjAuMTkzLjIxOTo0NDM


## anon-cs-serbia6

Belgrade, Serbia IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6N2Q6NDc6OjUzXTo0NDM


## anon-cs-singapore

Singapore Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gREzNy4xMjAuMTUxLjExOjQ0Mw


## anon-cs-singapore6

Singapore IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMmEwZDo1NjAwOjFmOjc6OjUzXTo0NDM


## anon-cs-sk

South Korea Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIxMDguMTgxLjUwLjIxODo0NDM


## anon-cs-sk6

South Korea IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRdbMjQwNjo0ZjQwOjQ6Yzo6NTNdOjQ0Mw


## anon-cs-swe

Sweden Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRMxMjguMTI3LjEwNC4xMDg6NDQz


## anon-cs-swe6

Sweden IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRdbMmEwMDo3MTQyOjE6MTo6NTNdOjQ0Mw


## anon-cs-sydney

Sydney, Australia Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIzNy4xMjAuMjM0LjI1MTo0NDM


## anon-cs-sydney6

Sydney, Australia IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6ODQ6NGQ6OjUzXTo0NDM


## anon-cs-tokyo

Tokyo, Japan Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRAxNDYuNzAuMzEuNDM6NDQz


## anon-cs-tokyo6

Tokyo, Japan IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRhbMjAwMTphYzg6NDA6ZGY6OjUzXTo0NDM


## anon-cs-tx

US - Dallas, TX Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gREyMDkuNTguMTQ3LjM2OjQ0Mw


## anon-cs-tx6

US - Dallas, TX IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gR9bMjYwNjo5ODgwOjIxMDA6YTAwNjozOjo1M106NDQz


## anon-cs-vancouver

Vancouver, Canada Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRIxOTYuMjQwLjc5LjE2Mzo0NDM


## anon-cs-vancouver6

Vancouver, Canada IPv6 Anonymized DNS relay server provided by https://cryptostorm.is/

sdns://gRlbMmEwMjo1NzQwOjI0OjQ1Ojo1M106NDQz


## anon-digitalprivacy.diy-ipv4

IPv4 server. Anonymized DNS relay hosted in Nuremberg, Germany (netcup) and maintained by https://digitalprivacy.diy

sdns://gRIzNy4yMjEuMTk0Ljg0OjQ0MzQ


## anon-dnswarden-swiss

Relay hosted in swizterland.
For more information look at https://github.com/bhanupratapys/dnswarden or https://dnswarden.com

sdns://gRQxODguMjQ0LjExNy4xMTQ6MTQ0Mw


## anon-inconnu

Anonymized DNS relay hosted in Seattle, WA (USA), maintained by Eric
Lagergren (@ericlagergren). Running the official Docker image on Vultr.

sdns://gQ4xMDQuMjM4LjE1My40Ng


## anon-kama

Anonymized DNS relay hosted in France and maintained by Frank Denis (@jedisct1).

sdns://gQ4xMzcuNzQuMjIzLjIzNA


## anon-saldns01-conoha-ipv4

Hosted on ConoHa VPS Tokyo region. No log. From experimental &mu;ODNS project https://junkurihara.github.io/dns/.

sdns://gRQxNjMuNDQuMTI0LjIwNDo1MDQ0Mw


## anon-saldns02-conoha-ipv4

Hosted on ConoHa VPS Tokyo region. No log. From experimental &mu;ODNS project https://junkurihara.github.io/dns/.

sdns://gRUxNjAuMjUxLjIxNC4xNzI6NTA0NDM


## anon-saldns03-conoha-ipv4

Hosted on ConoHa VPS Tokyo region. No log. From experimental &mu;ODNS project https://junkurihara.github.io/dns/.

sdns://gRQxNjAuMjUxLjE2OC4yNTo1MDQ0Mw


## anon-scaleway

Anonymized DNS relay hosted in France and maintained by Frank Denis (@jedisct1).

sdns://gRIyMTIuNDcuMjI4LjEzNjo0NDM


## anon-scaleway-ams

Anonymized DNS relay hosted in Amsterdam and maintained by Frank Denis (@jedisct1).

sdns://gRE1MS4xNS4xMjIuMjUwOjQ0Mw


## anon-scaleway-ams-ipv6

Anonymized DNS relay hosted in Amsterdam and maintained by Frank Denis (@jedisct1).
IPv6 only.

sdns://gSpbMjAwMTpiYzg6MTY0MDoxY2UyOmRjMDA6ZmY6ZmUyODo1YjE3XTo0NDM


## anon-scaleway-ipv6

Anonymized DNS relay hosted in France and maintained by Frank Denis (@jedisct1).
IPv6 only.

sdns://gSlbMjAwMTpiYzg6NzEwOjU4MTg6ZGMwMDpmZjpmZTViOjNmNjNdOjQ0Mw


## anon-scaleway2

Anonymized DNS relay hosted in France and maintained by Frank Denis (@jedisct1).

sdns://gRMxNjMuMTcyLjE4MC4xMjU6NDQz


## anon-serbica

Anonymized DNS relay hosted in Netherlands by https://litepay.ch

sdns://gRMxODUuNjYuMTQzLjE3ODo1MzUz


## anon-tiarap

Anonymized DNS relay hosted in Singapore

sdns://gRMxNzQuMTM4LjI5LjE3NToxNDQz


## dnscry.pt-anon-adelaide-ipv4

DNSCry.pt Adelaide - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xNjMuNDcuMTE5LjE4Mg


## dnscry.pt-anon-adelaide-ipv6

DNSCry.pt Adelaide - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSVbMjQwMDpjNDAxOjEwMDI6MTE6YmVlOmNlZTo5NThjOjg3M2Jd


## dnscry.pt-anon-allendale-ipv4

DNSCry.pt Allendale - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwzOC4yNDcuMy4xMDc


## dnscry.pt-anon-allendale-ipv6

DNSCry.pt Allendale - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwMjpmN2EzOjA6NTIwMDo6YV0


## dnscry.pt-anon-amsterdam-ipv4

DNSCry.pt Amsterdam - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xOTguMTQwLjE0MS40Ng


## dnscry.pt-anon-amsterdam-ipv6

DNSCry.pt Amsterdam - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRZbMmEwMzo5NGUzOjIyMmI6OjEwMzJd


## dnscry.pt-anon-amsterdam02-ipv4

DNSCry.pt Amsterdam 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ00NS44Ni4xNjIuMTEw


## dnscry.pt-anon-amsterdam02-ipv6

DNSCry.pt Amsterdam 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMmEwNzplZmMwOjEwMDE6YTVjZTo6YjRiNF0


## dnscry.pt-anon-amsterdam03-ipv4

DNSCry.pt Amsterdam 03 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0yMy4xMzcuMjQ5LjI2


## dnscry.pt-anon-amsterdam03-ipv6

DNSCry.pt Amsterdam 03 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwMjpmYzI0OjEyOjk4NzM6OmFiMV0


## dnscry.pt-anon-ashburn-ipv4

DNSCry.pt Ashburn - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ43Ny4yNDcuMTI3LjEwNw


## dnscry.pt-anon-ashburn-ipv6

DNSCry.pt Ashburn - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwYTo4ZGMwOmEwNjc6OmFd


## dnscry.pt-anon-athens-ipv4

DNSCry.pt Athens - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xODUuMjM0LjUyLjg3


## dnscry.pt-anon-athens-ipv6

DNSCry.pt Athens - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwOTpjZDQzOmY6NDJhMTo6NV0


## dnscry.pt-anon-atlanta-ipv4

DNSCry.pt Atlanta - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNzAuMjQ5LjIzNy4xNTQ


## dnscry.pt-anon-atlanta-ipv6

DNSCry.pt Atlanta - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjYwMDo0YzAwOjgwOjg6OmFd


## dnscry.pt-anon-auckland-ipv4

DNSCry.pt Auckland - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xODUuOTkuMTMzLjExMg


## dnscry.pt-anon-auckland-ipv6

DNSCry.pt Auckland - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRxbMmEwNjoxMjgwOmJlZTE6Mjo6ZWUxMjoyMDhd


## dnscry.pt-anon-baku-ipv4

DNSCry.pt Baku - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xODAuMTQ5LjQ0LjIy


## dnscry.pt-anon-baku-ipv6

DNSCry.pt Baku - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwMzo5MGMwOjE5NTo6OTFd


## dnscry.pt-anon-bangkok-ipv4

DNSCry.pt Bangkok - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDMuMzguMjUwLjU1


## dnscry.pt-anon-bangkok-ipv6

DNSCry.pt Bangkok - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMjAwMTpkZjE6ODhjMDoyMDA6OjE0XQ


## dnscry.pt-anon-barcelona-ipv4

DNSCry.pt Barcelona - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs0Ni4yOC43MS41Mg


## dnscry.pt-anon-barcelona-ipv6

DNSCry.pt Barcelona - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmExMjo2ZmM0OjgwMDA6Ojg5XQ


## dnscry.pt-anon-bengaluru-ipv4

DNSCry.pt Bengaluru - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNjAuMTkxLjE4Mi4yMTY


## dnscry.pt-anon-bengaluru-ipv6

DNSCry.pt Bengaluru - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRZbMjQwMTpkNGUwOjE6ZjdmZDo6NTNd


## dnscry.pt-anon-berkeleysprings-ipv4

DNSCry.pt Berkeley Springs - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xOTMuNDIuMjQ2LjEwOA


## dnscry.pt-anon-berkeleysprings-ipv6

DNSCry.pt Berkeley Springs - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMjYwNjo2NjgwOjM3OjE6OmM5ODQ6NGJhM10


## dnscry.pt-anon-bogota-ipv4

DNSCry.pt Bogotá - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDMuNTcuMjUwLjU0


## dnscry.pt-anon-bogota-ipv6

DNSCry.pt Bogotá - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwMzpmODA6NTc6OThiMTo6MV0


## dnscry.pt-anon-bratislava-ipv4

DNSCry.pt Bratislava - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ45NS4xMzEuMjAyLjEwNQ


## dnscry.pt-anon-bratislava-ipv6

DNSCry.pt Bratislava - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR1bMmEwNTo1NTAyOjo1OTA2Ojk3Zjg6MmQwZToxXQ


## dnscry.pt-anon-brisbane-ipv4

DNSCry.pt Brisbane - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ40My4yMjQuMTgwLjEzNw


## dnscry.pt-anon-brisbane-ipv6

DNSCry.pt Brisbane - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSJbMjQwNDo5NDAwOjE6MDoyMTY6M2VmZjpmZWY2OjcxOTRd


## dnscry.pt-anon-brussels-ipv4

DNSCry.pt Brussels - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xOTIuMTIxLjE3MC4xNTE


## dnscry.pt-anon-brussels-ipv6

DNSCry.pt Brussels - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwMzpmODA6MzI6NTJkOTo6MV0


## dnscry.pt-anon-bucharest-ipv4

DNSCry.pt Bucharest - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xODUuOTMuMjIxLjE2Nw


## dnscry.pt-anon-bucharest-ipv6

DNSCry.pt Bucharest - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMmEwZDo5ZWMyOjA6ZjAzZDo6YzQ5ZV0


## dnscry.pt-anon-budapest-ipv4

DNSCry.pt Budapest - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xOTMuMjAxLjE4NS4xNDY


## dnscry.pt-anon-budapest-ipv6

DNSCry.pt Budapest - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMmEwMTo2ZWUwOjE6OmZmZmY6YmFlXQ


## dnscry.pt-anon-calgary-ipv4

DNSCry.pt Calgary - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0yMy4xMzMuNjQuMTIx


## dnscry.pt-anon-calgary-ipv6

DNSCry.pt Calgary - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRZbMjYwMjpmZWQyOmZlMDoyODM6OjFd


## dnscry.pt-anon-capetown-ipv4

DNSCry.pt Cape Town - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDIuMjE2Ljc5LjIzNw


## dnscry.pt-anon-capetown-ipv6

DNSCry.pt Cape Town - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMmMwZjplZjE4OjlmZmY6MTpiZmY6OmFd


## dnscry.pt-anon-capetown02-ipv4

DNSCry.pt Cape Town 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNjAuMTE5LjIzMy4yNDU


## dnscry.pt-anon-capetown02-ipv6

DNSCry.pt Cape Town 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMmMwZjpmMDMwOjEwMDA6MjMzOjoyNDVd


## dnscry.pt-anon-chicago-ipv4

DNSCry.pt Chicago - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ00NS40MS4yMDQuMjA0


## dnscry.pt-anon-chicago-ipv6

DNSCry.pt Chicago - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR9bMjYwMjpmZWE3OmUwYzplOmJmZjo2OjcwOjE5NGNd


## dnscry.pt-anon-chisinau-ipv4

DNSCry.pt Chișinău - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xNzYuMTIzLjEwLjEwNQ


## dnscry.pt-anon-chisinau-ipv6

DNSCry.pt Chișinău - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR1bMjAwMTo2Nzg6NmQ0OjUwODA6OjNkZWE6MTA5XQ


## dnscry.pt-anon-copenhagen-ipv4

DNSCry.pt Copenhagen - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xOTIuMTIxLjExOS4xOQ


## dnscry.pt-anon-copenhagen-ipv6

DNSCry.pt Copenhagen - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSNbMjAwMTo2N2M6YmVjOmI6NDNhOjFhZmY6ZmViMTplYjVkXQ


## dnscry.pt-anon-coventry-ipv4

DNSCry.pt Coventry - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ00NS4xNTUuMzcuMTY1


## dnscry.pt-anon-coventry-ipv6

DNSCry.pt Coventry - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMmEwZDpkOGMwOjA6ZjA0Mzo6NjkyN10


## dnscry.pt-anon-dallas-ipv6

DNSCry.pt Dallas - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjYwMjpmYjk0OjE6Mzk6OmFd


## dnscry.pt-anon-denver-ipv4

DNSCry.pt Denver - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8yMTYuMTIwLjIwMS4xMDU


## dnscry.pt-anon-denver-ipv6

DNSCry.pt Denver - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwNzphNjgwOjY6ZjAxNjo6M2EyNV0


## dnscry.pt-anon-detroit-ipv4

DNSCry.pt Detroit - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw2Ni4xODcuNy4xNDA


## dnscry.pt-anon-detroit-ipv6

DNSCry.pt Detroit - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSNbMjYwNjo2NWMwOjQwOjQ6NWYzOjU0YzQ6OGQxMDo5Yjk4XQ


## dnscry.pt-anon-dhaka-ipv4

DNSCry.pt Dhaka - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDMuMTc0LjUxLjcx


## dnscry.pt-anon-dhaka-ipv6

DNSCry.pt Dhaka - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjAwMTpkZjE6OGY0MDo1MTo6YV0


## dnscry.pt-anon-dublin-ipv4

DNSCry.pt Dublin - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xOTQuMjYuMjEzLjE1


## dnscry.pt-anon-dublin-ipv6

DNSCry.pt Dublin - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwOTpjZDQ2OmY6NDI5ZTo6NV0


## dnscry.pt-anon-durham-ipv4

DNSCry.pt Durham - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwzOC40NS42NC4xMTc


## dnscry.pt-anon-durham-ipv6

DNSCry.pt Durham - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR1bMjAwMTo1NTA6NWEwMDo1ZWI6OmRiNTpmYWNlXQ


## dnscry.pt-anon-dusseldorf-ipv4

DNSCry.pt Düsseldorf - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ01LjE3NS4xODAuMTcx


## dnscry.pt-anon-dusseldorf-ipv6

DNSCry.pt Düsseldorf - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRpbMmEwZjo2Mjg0OjQzMDA6MTAxOjoxMmE1XQ


## dnscry.pt-anon-dusseldorf02-ipv6

DNSCry.pt Düsseldorf 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRZbMmEwNjpkZTAwOjQwMToyMjc6OjJd


## dnscry.pt-anon-ebenecity-ipv4

DNSCry.pt Ebène City - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDIuMjIyLjEwNi45Ng


## dnscry.pt-anon-ebenecity-ipv6

DNSCry.pt Ebène City - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR9bMmMwZjplOGY4OjIwMDA6MjMzOjo0MjU0OmM1YjJd


## dnscry.pt-anon-ebenecity02-ipv4

DNSCry.pt Ebène City 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwxOTYuNDYuNTAuOTM


## dnscry.pt-anon-eygelshoven-ipv4

DNSCry.pt Eygelshoven - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw5My45NS4xMTUuMjE


## dnscry.pt-anon-eygelshoven-ipv6

DNSCry.pt Eygelshoven - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gQ5bMmExMDpjYTgwOjphXQ


## dnscry.pt-anon-flint-ipv4

DNSCry.pt Flint - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNDcuMTg5LjE0MC4xMzY


## dnscry.pt-anon-flint-ipv6

DNSCry.pt Flint - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMjYwNjo2NjgwOjI5OjE6OjU4NTk6YTM3Yl0


## dnscry.pt-anon-frankfurt02-ipv4

DNSCry.pt Frankfurt 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ00NS4xNDcuNTEuMTIz


## dnscry.pt-anon-frankfurt02-ipv6

DNSCry.pt Frankfurt 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmEwNzpkODg0OjEwMDo6MzQ0XQ


## dnscry.pt-anon-fremont02-ipv4

DNSCry.pt Fremont 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwxNjcuODguNDguMTg


## dnscry.pt-anon-fremont02-ipv6

DNSCry.pt Fremont 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwMjpmZWQyOjcxOTg6N2FmMTo6MV0


## dnscry.pt-anon-fujairah-ipv4

DNSCry.pt Fujairah - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw4OS4zNi4xNjIuNzY


## dnscry.pt-anon-fujairah-ipv6

DNSCry.pt Fujairah - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSdbMmEwNjpmOTAyOjQwMDE6MTAwOjkwMDA6OTAwMDpmOTBiOjNlYV0


## dnscry.pt-anon-gdansk-ipv4

DNSCry.pt Gdańsk - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ04Mi4xMTguMjEuMTg5


## dnscry.pt-anon-gdansk-ipv6

DNSCry.pt Gdańsk - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRBbMmEwNTo5NDA0Ojo4OTld


## dnscry.pt-anon-geneva-ipv4

DNSCry.pt Geneva - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw0NS45MC41OS4xOTM


## dnscry.pt-anon-geneva-ipv6

DNSCry.pt Geneva - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRBbMmEwNTo5NDA2OjphZTFd


## dnscry.pt-anon-grandrapids-ipv4

DNSCry.pt Grand Rapids - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xODUuMTY1LjQ0LjE2NA


## dnscry.pt-anon-grandrapids-ipv6

DNSCry.pt Grand Rapids - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjYwMjpmOTY0OjE6MjQ6OmFd


## dnscry.pt-anon-guayaquil-ipv4

DNSCry.pt Guayaquil - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQsyMDUuMjM1LjIuMw


## dnscry.pt-anon-guayaquil-ipv6

DNSCry.pt Guayaquil - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjgwMzpjMzEwOmZmMDI6M2IxNDo6MV0


## dnscry.pt-anon-hafnarfjordur-ipv4

DNSCry.pt Hafnarfjordur - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xOTIuNzEuMjE4LjEyMQ


## dnscry.pt-anon-hafnarfjordur-ipv6

DNSCry.pt Hafnarfjordur - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRZbMmEwMzpmODA6MzU0OjM2YTE6OjFd


## dnscry.pt-anon-halifax-ipv4

DNSCry.pt Halifax - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwyMy4xOTEuODAuNDM


## dnscry.pt-anon-halifax-ipv6

DNSCry.pt Halifax - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwMjpmYzFjOmZhMDoyOTo6MV0


## dnscry.pt-anon-hanoi-ipv4

DNSCry.pt Hanoi - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDMuMTk5LjE2Ljkz


## dnscry.pt-anon-hanoi-ipv6

DNSCry.pt Hanoi - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjQwNDpmYmMwOjA6MTFjODo6YTMyNF0


## dnscry.pt-anon-helsinki-ipv4

DNSCry.pt Helsinki - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4zNy4yMjguMTI5LjE2MA


## dnscry.pt-anon-helsinki-ipv6

DNSCry.pt Helsinki - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwNjoxNzAwOjE6M2E6OmNiYV0


## dnscry.pt-anon-hongkong-ipv4

DNSCry.pt Hong Kong - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs5Ni45LjIyOC4yNw


## dnscry.pt-anon-hongkong-ipv6

DNSCry.pt Hong Kong - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMjAwMTpkZjE6ODAxOmEwMjI6OmM0OmFd


## dnscry.pt-anon-hongkong02-ipv6

DNSCry.pt Hong Kong 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwMjpmYTY3OjEwMToxZDo6YV0


## dnscry.pt-anon-hongkong03-ipv4

DNSCry.pt Hong Kong 03 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ40NS4xMjMuMTg4LjEyOQ


## dnscry.pt-anon-hongkong03-ipv6

DNSCry.pt Hong Kong 03 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMjQwNjo0MzAwOmJhZTo2YjA4OjoxXQ


## dnscry.pt-anon-houston-ipv4

DNSCry.pt Houston - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4yMDkuMTM1LjE3MC41MQ


## dnscry.pt-anon-houston-ipv6

DNSCry.pt Houston - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMjYwMjpmOWYzOjA6Mjo6MTkzXQ


## dnscry.pt-anon-hudiksvall-ipv4

DNSCry.pt Hudiksvall - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ05NS4xNDMuMTk2LjE2


## dnscry.pt-anon-hudiksvall-ipv6

DNSCry.pt Hudiksvall - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMmEwMzpkNzgwOjA6MTk2OjozOjU2YWZd


## dnscry.pt-anon-ikeja-ipv4

DNSCry.pt Ikeja - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xNjcuODguNTEuMjQ1


## dnscry.pt-anon-ikeja-ipv6

DNSCry.pt Ikeja - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMmEwMTplMjgxOmFjMDE6ZmQwZDo6MV0


## dnscry.pt-anon-indianapolis-ipv4

DNSCry.pt Indianapolis - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4yMy4xNjguMTM2LjE0NA


## dnscry.pt-anon-indianapolis-ipv6

DNSCry.pt Indianapolis - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMjYwMjpmOWJkOjgwOjExOjphXQ


## dnscry.pt-anon-islamabad-ipv4

DNSCry.pt Islamabad - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDMuOTkuMTMzLjExMA


## dnscry.pt-anon-islamabad-ipv6

DNSCry.pt Islamabad - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMjAwMTpkZjI6ZDQwOjI5OjoyXQ


## dnscry.pt-anon-istanbul-ipv4

DNSCry.pt Istanbul - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xODguMTMyLjE5Mi4xNjg


## dnscry.pt-anon-istanbul-ipv6

DNSCry.pt Istanbul - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRpbMmExMjplMzQyOjMwMDo6ZGFjYTo2M2VhXQ


## dnscry.pt-anon-jacksonville-ipv4

DNSCry.pt Jacksonville - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xMDQuMjI1LjEyOS4xMDY


## dnscry.pt-anon-jacksonville-ipv6

DNSCry.pt Jacksonville - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwNzphNjgwOjQ6ZjAwMzo6ZWMzMl0


## dnscry.pt-anon-jakarta-ipv4

DNSCry.pt Jakarta - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xNTEuMjQzLjIyMi45NA


## dnscry.pt-anon-jena-ipv4

DNSCry.pt Jena - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs4MS43LjExLjI0Ng


## dnscry.pt-anon-jena-ipv6

DNSCry.pt Jena - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwMjoxODA6NjoxOjo4YjRd


## dnscry.pt-anon-johannesburg-ipv4

DNSCry.pt Johannesburg - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNjkuMjM5LjEyOC4xMjQ


## dnscry.pt-anon-johannesburg-ipv6

DNSCry.pt Johannesburg - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmMwZjpmNTMwOjpkMDA6MTg4XQ


## dnscry.pt-anon-johannesburg02-ipv4

DNSCry.pt Johannesburg 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNjAuMTE5LjIzNC4xNTY


## dnscry.pt-anon-johannesburg02-ipv6

DNSCry.pt Johannesburg 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMmMwZjpmMDMwOjYwODA6MTo6MTU2XQ


## dnscry.pt-anon-johor-ipv6

DNSCry.pt Johor - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjAwMTpkZjQ6MTg0MDo5Zjo6YV0


## dnscry.pt-anon-kansascity-ipv4

DNSCry.pt Kansas City - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0yMy4xNTAuNDAuMTIx


## dnscry.pt-anon-kansascity-ipv6

DNSCry.pt Kansas City - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMjYwMjoyYjc6ZDAxOmMyOTU6OmI6MThd


## dnscry.pt-anon-kyiv-ipv4

DNSCry.pt Kyiv - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0yMTcuMTIuMjIxLjYx


## dnscry.pt-anon-kyiv-ipv6

DNSCry.pt Kyiv - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRBbMmEwMjoyN2FkOjoyMDFd


## dnscry.pt-anon-kyiv02-ipv6

DNSCry.pt Kyiv 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwMTpmNTAwOjI6MTUwMDo6YV0


## dnscry.pt-anon-lagos-ipv4

DNSCry.pt Lagos - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xNzYuOTcuMTkyLjEy


## dnscry.pt-anon-lagos-ipv6

DNSCry.pt Lagos - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR9bMmEwNjpmOTAxOjQwMDE6MTAwOjoyZDZjOjczNmFd


## dnscry.pt-anon-lasvegas-ipv4

DNSCry.pt Las Vegas - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs2Ni4xODcuNC4zOQ


## dnscry.pt-anon-lasvegas-ipv6

DNSCry.pt Las Vegas - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSVbMjYwNjo2NWMwOjEwOjE1ZDo5MmUwOmM3ZTU6YjU3OjViMDBd


## dnscry.pt-anon-libertylake-ipv4

DNSCry.pt Liberty Lake - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwyMy4xODQuNDguMTk


## dnscry.pt-anon-libertylake-ipv6

DNSCry.pt Liberty Lake - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwMjpmYzI0OjE4OjMzZjI6OmFiMV0


## dnscry.pt-anon-lima02-ipv4

DNSCry.pt Lima 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw4Ny4xMjEuOTkuMjM


## dnscry.pt-anon-lima02-ipv6

DNSCry.pt Lima 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwMzo5MGMwOjU1NTo6NzJd


## dnscry.pt-anon-lisbon-ipv4

DNSCry.pt Lisbon - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwxNDMuMjAuMTIuMzI


## dnscry.pt-anon-lisbon-ipv6

DNSCry.pt Lisbon - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmEwZjpjNDQyOjgwMDA6OjMyXQ


## dnscry.pt-anon-lisbon02-ipv4

DNSCry.pt Lisbon 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw5MS4yMDkuMTYuOTg


## dnscry.pt-anon-lisbon02-ipv6

DNSCry.pt Lisbon 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gQ9bMmEwZjpjNDQ0Ojo5OF0


## dnscry.pt-anon-ljubljana-ipv4

DNSCry.pt Ljubljana - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw5MS4xMzIuOTQuOTg


## dnscry.pt-anon-ljubljana-ipv6

DNSCry.pt Ljubljana - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRZbMmEwMzpmODA6Mzg2OmI3ZjY6OjFd


## dnscry.pt-anon-london-ipv4

DNSCry.pt London - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw0NS42Ny44NC4xMzI


## dnscry.pt-anon-london-ipv6

DNSCry.pt London - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjQwMTo4MzYwOmEyOjQ6OmFd


## dnscry.pt-anon-losangeles-ipv4

DNSCry.pt Los Angeles - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDQuMTU2LjE1NC4xMQ


## dnscry.pt-anon-losangeles-ipv6

DNSCry.pt Los Angeles - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRJbMjYwMjpmN2Y4Ojc6ZDo6YV0


## dnscry.pt-anon-losangeles02-ipv4

DNSCry.pt Los Angeles 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDQuMjAwLjY3LjE5NA


## dnscry.pt-anon-losangeles02-ipv6

DNSCry.pt Los Angeles 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMjYwMjpmZjc1Ojc6Yjc5OjpiNGI0XQ


## dnscry.pt-anon-luxembourg-ipv4

DNSCry.pt Luxembourg - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw0NS44MC4yMDkuNTU


## dnscry.pt-anon-luxembourg-ipv6

DNSCry.pt Luxembourg - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwMzo5MGMwOjg1OjoxMDJd


## dnscry.pt-anon-madrid-ipv4

DNSCry.pt Madrid - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ01LjEzNC4xMTguMTk4


## dnscry.pt-anon-madrid-ipv6

DNSCry.pt Madrid - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMmEwMzpjN2MwOjUyOjI2NDE6MTgwOjoxM10


## dnscry.pt-anon-manchester-ipv4

DNSCry.pt Manchester - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4yMTYuMjQ1LjE0MC4yMA


## dnscry.pt-anon-manchester-ipv6

DNSCry.pt Manchester - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwYTo4ZGMwOjYwNTg6OmFd


## dnscry.pt-anon-manila-ipv4

DNSCry.pt Manila - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDMuMzguMjUxLjYw


## dnscry.pt-anon-manila-ipv6

DNSCry.pt Manila - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjQwMTpmMmUwOjA6MTAyOjoxNF0


## dnscry.pt-anon-marseille-ipv4

DNSCry.pt Marseille - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ40NS4xNDAuMTY0LjEyNw


## dnscry.pt-anon-marseille-ipv6

DNSCry.pt Marseille - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRpbMmEwNjplODgxOjcwMDA6OmI4NTM6NDk1XQ


## dnscry.pt-anon-melbourne-ipv4

DNSCry.pt Melbourne - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDMuMTA4LjIyOC4xNQ


## dnscry.pt-anon-melbourne-ipv6

DNSCry.pt Melbourne - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjQwMjo3MzQwOjgwMDA6OjVd


## dnscry.pt-anon-miami-ipv4

DNSCry.pt Miami - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMjguMjU0LjIwNy41MA


## dnscry.pt-anon-miami-ipv6

DNSCry.pt Miami - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRJbMjYwMjpmN2Y4OjY6YTo6YV0


## dnscry.pt-anon-milan-ipv4

DNSCry.pt Milan - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ04Mi4xMTguMTYuMTIx


## dnscry.pt-anon-milan-ipv6

DNSCry.pt Milan - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwMjoyN2FlOjgwMDA6OjJhMV0


## dnscry.pt-anon-molln-ipv4

DNSCry.pt Mölln - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ05MS4xMDguODAuMTU5


## dnscry.pt-anon-molln-ipv6

DNSCry.pt Mölln - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwNTo5MDE6NjoxMDQ4Ojpd


## dnscry.pt-anon-montreal-ipv4

DNSCry.pt Montreal - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNDcuMTg5LjEzNi4xODM


## dnscry.pt-anon-montreal-ipv6

DNSCry.pt Montreal - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRpbMjYwNjo2NjgwOjQ1OjE6OmY3OGM6OWIwXQ


## dnscry.pt-anon-moscow-ipv4

DNSCry.pt Moscow - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ45My4xODMuMTA2LjIyMg


## dnscry.pt-anon-moscow-ipv6

DNSCry.pt Moscow - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRJbMmEwMzplMzQwOjM6Mzo6MV0


## dnscry.pt-anon-mumbai-ipv4

DNSCry.pt Mumbai - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDMuMTExLjExNC4yNQ


## dnscry.pt-anon-mumbai-ipv6

DNSCry.pt Mumbai - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR9bMmEwNjpmOTAyOjgwMDE6MTAwOjoxNzU3OmU2MTdd


## dnscry.pt-anon-mumbai02-ipv4

DNSCry.pt Mumbai 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwxNjUuOTkuOS4yMDk


## dnscry.pt-anon-mumbai02-ipv6

DNSCry.pt Mumbai 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRFbMjYwMjpmYTA4OjU6Ojc1XQ


## dnscry.pt-anon-munich-ipv4

DNSCry.pt Munich - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xOTQuMzkuMjA1LjEw


## dnscry.pt-anon-munich-ipv6

DNSCry.pt Munich - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRpbMmEwYzo4ZmMwOjE3NDk6NjY6MTg6OjE2XQ


## dnscry.pt-anon-naaldwijk-ipv4

DNSCry.pt Naaldwijk - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs0NS45NS4zOC4yOQ


## dnscry.pt-anon-naaldwijk-ipv6

DNSCry.pt Naaldwijk - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSBbMmEwMDo3YzgzOjA6MTI6MTRkMDpmNWI2OjRlYzphXQ


## dnscry.pt-anon-newyork-ipv4

DNSCry.pt New York - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xOTkuMTE5LjEzNy43NA


## dnscry.pt-anon-newyork-ipv6

DNSCry.pt New York - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRJbMjYwMjpmN2Y4OjI6Yzo6YV0


## dnscry.pt-anon-nuremberg-ipv4

DNSCry.pt Nuremberg - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0yMDIuNjEuMjM2LjY3


## dnscry.pt-anon-nuremberg-ipv6

DNSCry.pt Nuremberg - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSVbMmEwMzo0MDAwOjVjOjUxOjI0Yjk6NTFmZjpmZTgwOmYzYTdd


## dnscry.pt-anon-ogden-ipv4

DNSCry.pt Ogden - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDcuMTgyLjE3My44Mw


## dnscry.pt-anon-ogden-ipv6

DNSCry.pt Ogden - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwNzpmMmQ4OjQwMWI6MTA0NTo6YV0


## dnscry.pt-anon-oradea-ipv4

DNSCry.pt Oradea - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xODUuMjA3LjEyNS4xMDA


## dnscry.pt-anon-oradea-ipv6

DNSCry.pt Oradea - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR1bMmEwZDo4MTQ0OjA6ZjY6MjkxNTphZjowOjE4XQ


## dnscry.pt-anon-ottoville-ipv4

DNSCry.pt Ottoville - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xMDQuMjM0LjIzMS4yMzk


## dnscry.pt-anon-ottoville-ipv6

DNSCry.pt Ottoville - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjYwMjpmOTUzOjY6MjU6OmFd


## dnscry.pt-anon-palermo-ipv4

DNSCry.pt Palermo - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ05MS4yMDEuNjcuMTA3


## dnscry.pt-anon-palermo-ipv6

DNSCry.pt Palermo - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwNjpmOTA1OjE6MTAwOjo0MF0


## dnscry.pt-anon-paris-ipv4

DNSCry.pt Paris - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs4OS4xMTcuMi4xNw


## dnscry.pt-anon-paris-ipv6

DNSCry.pt Paris - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR5bMjQwMjpkMGMwOjIyOjZjZDA6NDo0OjQ6NWI4MV0


## dnscry.pt-anon-perth-ipv4

DNSCry.pt Perth - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4yMDMuMjkuMjQwLjI0OQ


## dnscry.pt-anon-perth-ipv6

DNSCry.pt Perth - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSJbMjQwNDo5NDAwOjQ6MDoyMTY6M2VmZjpmZWU2OmE3NjJd


## dnscry.pt-anon-philadelphia-ipv4

DNSCry.pt Philadelphia - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xNTQuMTYuMTU5LjIy


## dnscry.pt-anon-philadelphia-ipv6

DNSCry.pt Philadelphia - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwNDpiZjAwOjIxMDoxMjo6Ml0


## dnscry.pt-anon-phoenix-ipv4

DNSCry.pt Phoenix - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwyMy45NS4xMzQuMTU


## dnscry.pt-anon-phoenix-ipv6

DNSCry.pt Phoenix - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRJbMjYwNTo4MzQwOjM6Nzo6YV0


## dnscry.pt-anon-portedwards-ipv4

DNSCry.pt Port Edwards - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNzYuMTExLjIxOS4xMjY


## dnscry.pt-anon-portland-ipv4

DNSCry.pt Portland - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xMDMuMTI0LjEwNi4yMzM


## dnscry.pt-anon-portland-ipv6

DNSCry.pt Portland - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSFbMjQwMjpkMGMwOjE2OmExZTY6MDpiODkzOmJmNzpkZF0


## dnscry.pt-anon-prague-ipv4

DNSCry.pt Prague - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xOTUuMTIzLjI0NS4xOQ


## dnscry.pt-anon-prague-ipv6

DNSCry.pt Prague - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRBbMmEwNTo5NDAzOjo5OTld


## dnscry.pt-anon-queretaro-ipv4

DNSCry.pt Querétaro - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw4OS4yMjMuODguNzQ


## dnscry.pt-anon-queretaro-ipv6

DNSCry.pt Querétaro - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmEwMzo5MGMwOjU0NTo6MTFhXQ


## dnscry.pt-anon-redditch-ipv4

DNSCry.pt Redditch - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw0NS42Ny44NS4yMTk


## dnscry.pt-anon-redditch-ipv6

DNSCry.pt Redditch - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmEwNTo0MTQwOjE5OjUzOjphXQ


## dnscry.pt-anon-riga-ipv4

DNSCry.pt Riga - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xOTUuMTIzLjIxMi4yMDA


## dnscry.pt-anon-riga-ipv6

DNSCry.pt Riga - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRFbMmEwMjoyN2FjOjoxMjQ5XQ


## dnscry.pt-anon-saltlakecity-ipv4

DNSCry.pt Salt Lake City - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDMuMTE0LjE2Mi42NQ


## dnscry.pt-anon-saltlakecity-ipv6

DNSCry.pt Salt Lake City - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gSFbMjQwMjpkMGMwOjE4OmM4ZmY6MDpiODkzOmJmNzpkZF0


## dnscry.pt-anon-sandefjord-ipv4

DNSCry.pt Sandefjord - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xOTQuMzIuMTA3LjQ4


## dnscry.pt-anon-sandefjord-ipv6

DNSCry.pt Sandefjord - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwMzo5NGUwOjI3MWY6OjViMV0


## dnscry.pt-anon-sanjose-ipv4

DNSCry.pt San Jose - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xODUuMTA2Ljk2LjIxMA


## dnscry.pt-anon-sanjose-ipv6

DNSCry.pt San Jose - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMjYwNzpmMzU4OjFhOmU6OjhhYTI6OTMzM10


## dnscry.pt-anon-santaclara-ipv4

DNSCry.pt Santa Clara - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNzYuMTExLjIyMy4xNjc


## dnscry.pt-anon-santaclara-ipv6

DNSCry.pt Santa Clara - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMjYwNjo2NjgwOjM1OjE6OjUwNmQ6OGNlMl0


## dnscry.pt-anon-saopaulo-ipv4

DNSCry.pt Sao Paulo - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDguMTgxLjY5LjE1Mw


## dnscry.pt-anon-saopaulo-ipv6

DNSCry.pt Sao Paulo - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR5bMjYwNDo2NjAwOmZkMDA6OTE6OjFiOGI6M2EzY10


## dnscry.pt-anon-seattle-ipv4

DNSCry.pt Seattle - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8yMDkuMTgyLjIyNS4xMDM


## dnscry.pt-anon-seattle-ipv6

DNSCry.pt Seattle - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwNzphNjgwOjk6ZjAwNTo6ODZlN10


## dnscry.pt-anon-seoul-ipv4

DNSCry.pt Seoul - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ05Mi4zOC4xMzUuMTI4


## dnscry.pt-anon-seoul-ipv6

DNSCry.pt Seoul - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwMzo5MGMwOjEyNTo6ODhd


## dnscry.pt-anon-seoul02-ipv4

DNSCry.pt Seoul 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNTEuMjQ1LjEwNi4xODE


## dnscry.pt-anon-seoul02-ipv6

DNSCry.pt Seoul 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjQwNjplZjgwOjU6NDhhOTo6MV0


## dnscry.pt-anon-singapore-ipv4

DNSCry.pt Singapore - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xNTcuMjAuMTA1LjExNQ


## dnscry.pt-anon-singapore-ipv6

DNSCry.pt Singapore - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwNjpmYzQwOjQwMDM6Zjo6YV0


## dnscry.pt-anon-singapore02-ipv4

DNSCry.pt Singapore 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDMuMTc5LjQ0Ljcz


## dnscry.pt-anon-singapore02-ipv6

DNSCry.pt Singapore 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMjQwMTo0NTIwOjExMjI6OmFd


## dnscry.pt-anon-sofia-ipv4

DNSCry.pt Sofia - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs3OS4xMjQuNy40Mw


## dnscry.pt-anon-sofia-ipv6

DNSCry.pt Sofia - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMmEwMTo4NzQwOjE6ODYzOjozYjhjXQ


## dnscry.pt-anon-spokane-ipv4

DNSCry.pt Spokane - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xMDQuMzYuODYuMTgx


## dnscry.pt-anon-spokane-ipv6

DNSCry.pt Spokane - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMjYwNjphOGMwOjM6MjAyOjphXQ


## dnscry.pt-anon-stockholm02-ipv4

DNSCry.pt Stockholm 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xODUuMjMxLjEwMC4xMDY


## dnscry.pt-anon-stockholm02-ipv6

DNSCry.pt Stockholm 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gShbMmEwYzo1NzAwOjMxMzM6NjUwOjk2ZDU6OTlmZjpmZThiOjc0ZjRd


## dnscry.pt-anon-sydney02-ipv4

DNSCry.pt Sydney 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xOTUuMTE0LjE0Ljc0


## dnscry.pt-anon-sydney02-ipv6

DNSCry.pt Sydney 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjQwMjo3MzQwOjUwMDA6NjIwMDo6YV0


## dnscry.pt-anon-taipeh-ipv4

DNSCry.pt Taipeh - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDMuMTMxLjE4OS43NA


## dnscry.pt-anon-taipeh-ipv6

DNSCry.pt Taipeh - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMjQwMzpjZmMwOjEwMDQ6OjE5MjQ6YjRlZl0


## dnscry.pt-anon-tallinn-ipv4

DNSCry.pt Tallinn - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xODUuMTk0LjUzLjIy


## dnscry.pt-anon-tallinn-ipv6

DNSCry.pt Tallinn - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRJbMmEwNDo2ZjAwOjQ6OjE3YV0


## dnscry.pt-anon-tampa-ipv4

DNSCry.pt Tampa - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ8xNjUuMTQwLjExNy4yNDg


## dnscry.pt-anon-tampa-ipv6

DNSCry.pt Tampa - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMjYwMjpmY2MwOjIyMjI6OWQyZTo6NTNd


## dnscry.pt-anon-taos-ipv4

DNSCry.pt Taos - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ42My4xMzMuMjIzLjEzOA


## dnscry.pt-anon-taos-ipv6

DNSCry.pt Taos - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRtbMjYwNjo2NjgwOjUzOjE6Ojg0NmE6YmQ3OV0


## dnscry.pt-anon-tbilisi-ipv6

DNSCry.pt Tbilisi - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRpbMmExMjplMzQwOjMwMDo6MTc2ODphOTVmXQ


## dnscry.pt-anon-telaviv-ipv4

DNSCry.pt Tel Aviv - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw1LjE4OC4yMjcuMTM


## dnscry.pt-anon-telaviv-ipv6

DNSCry.pt Tel Aviv - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwMzo5MGMwOjFlNzo6Mzld


## dnscry.pt-anon-thessaloniki-ipv4

DNSCry.pt Thessaloniki - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQs4NS45MC4xOTcuNw


## dnscry.pt-anon-thessaloniki-ipv6

DNSCry.pt Thessaloniki - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRRbMmExMjo2ZmMzOjgwMDA6OjE5XQ


## dnscry.pt-anon-timisoara-ipv4

DNSCry.pt Timișoara - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw0NS4xMzQuNDguMjU


## dnscry.pt-anon-timisoara-ipv6

DNSCry.pt Timișoara - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR5bMmEwYzo5ZjAwOjI6ZDkyODo2ZjBhOmI0ZTI6Ol0


## dnscry.pt-anon-tirana-ipv4

DNSCry.pt Tirana - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xODUuNzUuMjQzLjgw


## dnscry.pt-anon-tirana-ipv6

DNSCry.pt Tirana - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gR1bMmExMzo5NDAzOjo3YTZhOjUzMDY6MWUzNToxXQ


## dnscry.pt-anon-tokyo-ipv4

DNSCry.pt Tokyo - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQw0NS42Ny44Ni4xMjM


## dnscry.pt-anon-tokyo-ipv6

DNSCry.pt Tokyo - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwNjpmYzQwOjQwMDI6ZDo6YV0


## dnscry.pt-anon-tokyo02-ipv4

DNSCry.pt Tokyo 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwxMDMuMTc5LjQ1LjY


## dnscry.pt-anon-tokyo02-ipv6

DNSCry.pt Tokyo 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRNbMmEwYTo2MDQwOjk3M2Q6OmFd


## dnscry.pt-anon-toronto-ipv4

DNSCry.pt Toronto - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xNzIuOTMuMTY3LjIxNA


## dnscry.pt-anon-toronto-ipv6

DNSCry.pt Toronto - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRhbMjYwNjo2MDgwOjIwMDE6MTA5OTo6YV0


## dnscry.pt-anon-toronto02-ipv4

DNSCry.pt Toronto 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ4xMDMuMTQ0LjE3Ny41Nw


## dnscry.pt-anon-toronto02-ipv6

DNSCry.pt Toronto 02 - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwMjpmZWQyOmZhMDo0YTo6MV0


## dnscry.pt-anon-tuusula-ipv4

DNSCry.pt Tuusula - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ02NS4yMS4yNTIuMjAx


## dnscry.pt-anon-tuusula-ipv6

DNSCry.pt Tuusula - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMmEwMTo0Zjk6YzAxMTpiODRlOjoxXQ


## dnscry.pt-anon-valdivia-ipv4

DNSCry.pt Valdivia - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0yMTYuNzMuMTU5LjI2


## dnscry.pt-anon-valdivia-ipv6

DNSCry.pt Valdivia - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMmEwNjphMDA2OmQxZDE6OjExNl0


## dnscry.pt-anon-vancouver-ipv4

DNSCry.pt Vancouver - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQwyMy4xNTQuODEuOTI


## dnscry.pt-anon-vancouver-ipv6

DNSCry.pt Vancouver - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRVbMjYwMjpmZWQyOmZiMDo2ZDo6MV0


## dnscry.pt-anon-vilnius-ipv4

DNSCry.pt Vilnius - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ0xNjIuMjU0Ljg2LjEz


## dnscry.pt-anon-vilnius-ipv6

DNSCry.pt Vilnius - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRdbMmExMzo5NDAxOjA6MTo6M2Q1ODoxXQ


## dnscry.pt-anon-yerevan-ipv4

DNSCry.pt Yerevan - DNSCrypt, no filter, no logs, DNSSEC support (IPv4 server)

https://www.dnscry.pt

sdns://gQ04NS45MC4yMDcuMTk5


## dnscry.pt-anon-yerevan-ipv6

DNSCry.pt Yerevan - DNSCrypt, no filter, no logs, DNSSEC support (IPv6 server)

https://www.dnscry.pt

sdns://gRlbMmEwMzo5MGMwOjVmMToyOTAzOjo1Mzld

